part of 'components.dart';

const _fastAnimationDuration = Duration(milliseconds: 160);